package com.ffboost.app

import android.content.Context
import rikka.shizuku.Shizuku

data class Disp(val w: Int, val h: Int, val dpi: Int) {
    fun at(p: Int) = Triple(w * p / 100 / 2 * 2, h * p / 100 / 2 * 2, dpi * p / 100)
}

object Sh {
    fun exec(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        return out
    }

    fun sh(cmd: String): String = runCatching { exec(cmd) }.getOrDefault("")

    fun disp(): Disp? {
        val s = Regex("Physical size: (\\d+)x(\\d+)").find(exec("wm size")) ?: return null
        val d = Regex("Physical density: (\\d+)").find(exec("wm density")) ?: return null
        return Disp(s.groupValues[1].toInt(), s.groupValues[2].toInt(), d.groupValues[1].toInt())
    }

    fun apply(d: Disp, p: Int) {
        if (p >= 100) { reset(); return }
        val (w, h, x) = d.at(p)
        exec("wm size ${w}x$h; wm density $x")
    }

    fun reset() { exec("wm size reset; wm density reset") }
}

object Turbo {
    val GAMES = listOf("com.dts.freefireth", "com.dts.freefiremax")
    private const val PLAY = "com.android.vending"
    private val HEAVY = listOf(
        "com.instagram.android", "com.zhiliaoapp.musically", "com.facebook.katana",
        "com.google.android.youtube", "com.android.chrome", "com.kwai.video"
    )

    fun prefs(c: Context) = c.getSharedPreferences("ffboost", Context.MODE_PRIVATE)

    fun on(c: Context, withRes: Boolean) {
        val p = prefs(c)
        if (p.getBoolean("active", false)) return
        val done = mutableSetOf<String>()
        val e = p.edit()

        if (withRes) {
            val d = runCatching { Sh.disp() }.getOrNull()
            val pct = p.getInt("pct", 75)
            if (d != null && pct < 100) { Sh.sh("wm size ${d.at(pct).first}x${d.at(pct).second}; wm density ${d.at(pct).third}"); done.add("res") }
        }
        if (p.getBoolean("kill", true)) {
            Sh.sh("am kill-all")
            HEAVY.forEach { Sh.sh("am force-stop $it") }
        }
        if (p.getBoolean("bg", true)) {
            e.putBoolean("saved_ds", Sh.sh("cmd netpolicy get restrict-background").contains("enabled"))
            Sh.sh("cmd appops set $PLAY RUN_IN_BACKGROUND ignore; cmd appops set $PLAY RUN_ANY_IN_BACKGROUND ignore; am force-stop $PLAY; cmd netpolicy set restrict-background true")
            done.add("bg")
        }
        if (p.getBoolean("dnd", true)) {
            e.putInt("saved_zen", Sh.sh("settings get global zen_mode").trim().toIntOrNull() ?: 0)
            Sh.sh("settings put global zen_mode 1")
            done.add("dnd")
        }
        if (p.getBoolean("anim", true)) {
            Sh.sh("settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5")
            done.add("anim")
        }
        if (p.getBoolean("game", true)) {
            GAMES.forEach { Sh.sh("cmd game mode performance $it") }
            done.add("game")
        }
        e.putStringSet("done", done).putBoolean("active", true).apply()
    }

    fun off(c: Context) {
        val p = prefs(c)
        val done = p.getStringSet("done", emptySet()) ?: emptySet()
        if ("res" in done) Sh.sh("wm size reset; wm density reset")
        if ("bg" in done) Sh.sh("cmd appops set $PLAY RUN_IN_BACKGROUND default; cmd appops set $PLAY RUN_ANY_IN_BACKGROUND default; cmd netpolicy set restrict-background ${p.getBoolean("saved_ds", false)}")
        if ("dnd" in done) Sh.sh("settings put global zen_mode ${p.getInt("saved_zen", 0)}")
        if ("anim" in done) Sh.sh("settings put global window_animation_scale 1.0; settings put global transition_animation_scale 1.0; settings put global animator_duration_scale 1.0")
        if ("game" in done) GAMES.forEach { Sh.sh("cmd game mode standard $it") }
        p.edit().putBoolean("active", false).putStringSet("done", emptySet()).apply()
    }
}
