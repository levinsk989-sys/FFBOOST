package com.ffboost.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.*
import rikka.shizuku.Shizuku

class AutoService : Service() {
    private var job: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel("ffboost", "FF Boost", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "ffboost")
            .setContentTitle("FF Boost")
            .setContentText("Turbo automático ligado: esperando o Free Fire abrir")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        if (job == null) job = CoroutineScope(Dispatchers.IO).launch { loop() }
        return START_STICKY
    }

    private suspend fun loop() {
        var mine = false
        var miss = 0
        while (currentCoroutineContext().isActive) {
            try {
                if (Shizuku.pingBinder()) {
                    val out = Sh.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'")
                    val inGame = Turbo.GAMES.any { out.contains(it) }
                    val active = Turbo.prefs(this@AutoService).getBoolean("active", false)
                    if (inGame) {
                        miss = 0
                        if (!active) { Turbo.on(this@AutoService, false); mine = true }
                    } else if (mine && active) {
                        miss++
                        if (miss >= 2) { Turbo.off(this@AutoService); mine = false; miss = 0 }
                    }
                }
            } catch (e: Exception) { }
            delay(3000)
        }
    }

    override fun onDestroy() {
        job?.cancel()
        job = null
        super.onDestroy()
    }
}
