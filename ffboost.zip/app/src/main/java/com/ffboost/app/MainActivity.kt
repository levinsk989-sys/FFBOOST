package com.ffboost.app

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import rikka.shizuku.Shizuku

private val Red = Color(0xFFE10600)
private val Bg = Color(0xFF0A0A0A)
private val Panel = Color(0xFF181818)
private val Gray = Color(0xFF9A9A9A)

fun openGame(ctx: Context): Boolean {
    val pm = ctx.packageManager
    val i = Turbo.GAMES.firstNotNullOfOrNull { pm.getLaunchIntentForPackage(it) } ?: return false
    ctx.startActivity(i)
    return true
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 0)
        }
        setContent { App() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val sp = remember { Turbo.prefs(ctx) }

    var status by remember { mutableStateOf(0) }
    var disp by remember { mutableStateOf<Disp?>(null) }
    var pct by remember { mutableStateOf(sp.getInt("pct", 75)) }
    var bg by remember { mutableStateOf(sp.getBoolean("bg", true)) }
    var kill by remember { mutableStateOf(sp.getBoolean("kill", true)) }
    var game by remember { mutableStateOf(sp.getBoolean("game", true)) }
    var dnd by remember { mutableStateOf(sp.getBoolean("dnd", true)) }
    var anim by remember { mutableStateOf(sp.getBoolean("anim", true)) }
    var auto by remember { mutableStateOf(sp.getBoolean("auto", false)) }
    var active by remember { mutableStateOf(sp.getBoolean("active", false)) }
    var countdown by remember { mutableStateOf(0) }
    var job by remember { mutableStateOf<Job?>(null) }
    var msg by remember { mutableStateOf("") }
    var batt by remember { mutableStateOf("") }

    fun save(k: String, v: Boolean) { sp.edit().putBoolean(k, v).apply() }
    fun startAuto() { ctx.startForegroundService(Intent(ctx, AutoService::class.java)) }
    fun stopAuto() { ctx.stopService(Intent(ctx, AutoService::class.java)) }

    fun refresh() {
        status = when {
            !Shizuku.pingBinder() -> 0
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> 1
            else -> 2
        }
        if (status == 2) scope.launch {
            disp = withContext(Dispatchers.IO) { runCatching { Sh.disp() }.getOrNull() }
        }
    }

    LaunchedEffect(Unit) { refresh() }
    LaunchedEffect(status) { if (status == 2 && auto) startAuto() }
    LaunchedEffect(Unit) {
        while (true) {
            val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            if (i != null) {
                batt = "Bateria ${i.getIntExtra("level", 0)}%   |   ${i.getIntExtra("temperature", 0) / 10.0} °C"
            }
            active = sp.getBoolean("active", false)
            delay(4000)
        }
    }
    DisposableEffect(Unit) {
        val l = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }
        Shizuku.addRequestPermissionResultListener(l)
        onDispose { Shizuku.removeRequestPermissionResultListener(l) }
    }

    fun turboOn() {
        job?.cancel(); countdown = 0
        scope.launch {
            withContext(Dispatchers.IO) { runCatching { Turbo.on(ctx, true) } }
            active = true
            msg = if (openGame(ctx)) "Turbo ligado. Abrindo Free Fire" else "Turbo ligado, mas o Free Fire não foi encontrado"
        }
    }

    fun turboOff() {
        job?.cancel(); countdown = 0
        scope.launch {
            withContext(Dispatchers.IO) {
                runCatching { Turbo.off(ctx) }
                runCatching { Sh.reset() }
            }
            active = false
            msg = "Tudo restaurado ao normal"
        }
    }

    fun test() {
        val d = disp ?: return
        job?.cancel()
        job = scope.launch {
            withContext(Dispatchers.IO) { runCatching { Sh.apply(d, pct) } }
            countdown = 15
            while (countdown > 0) { delay(1000); countdown-- }
            withContext(Dispatchers.IO) { runCatching { Sh.reset() } }
            msg = "Sem confirmação: resolução voltou ao padrão"
        }
    }

    fun confirm() { job?.cancel(); countdown = 0; msg = "Resolução mantida" }

    Column(
        Modifier.fillMaxSize().background(Bg)
            .verticalScroll(rememberScrollState()).padding(20.dp)
    ) {
        Text("FF BOOST", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black)
        Text("Free Fire mais liso, sem lag", color = Gray, fontSize = 14.sp)
        Spacer(Modifier.height(16.dp))

        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(16.dp)) {
            Column {
                Text(
                    when (status) {
                        0 -> "Shizuku desligado. Abra o app Shizuku e inicie o serviço."
                        1 -> "Falta permissão do Shizuku para este app."
                        else -> disp?.let { "Tela original: ${it.w}x${it.h}  (${it.dpi} dpi)" } ?: "Lendo a tela..."
                    },
                    color = Color.White, fontSize = 15.sp
                )
                if (batt.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text(batt, color = Gray, fontSize = 13.sp)
                }
                if (active) {
                    Spacer(Modifier.height(6.dp))
                    Text("TURBO LIGADO", color = Red, fontSize = 14.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        Spacer(Modifier.height(14.dp))

        if (status == 0) Btn("Verificar de novo", true) { refresh() }
        if (status == 1) Btn("Dar permissão", true) { Shizuku.requestPermission(1) }

        val d = disp
        if (status == 2 && d != null) {
            Text("Resolução", color = Gray, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(100, 90, 75, 60).forEach { v ->
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                            .background(if (v == pct) Red else Panel)
                            .clickable { pct = v; sp.edit().putInt("pct", v).apply() }
                            .padding(vertical = 16.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("$v%", color = Color.White, fontWeight = FontWeight.Bold) }
                }
            }
            val (w, h, x) = d.at(pct)
            Spacer(Modifier.height(8.dp))
            Text("Resultado: ${w}x$h  ($x dpi)", color = Gray, fontSize = 13.sp)
            Spacer(Modifier.height(16.dp))

            Text("Funções do Turbo", color = Gray, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Tog("Bloquear downloads e atualizações", "Segura a Play Store e os dados em segundo plano dos outros apps", bg) { bg = it; save("bg", it) }
            Spacer(Modifier.height(8.dp))
            Tog("Limpar apps em segundo plano", "Libera RAM e fecha Instagram, TikTok, Facebook, YouTube, Chrome e Kwai", kill) { kill = it; save("kill", it) }
            Spacer(Modifier.height(8.dp))
            Tog("Modo desempenho do jogo", "Pede ao Android prioridade máxima para o Free Fire (Android 12 ou mais)", game) { game = it; save("game", it) }
            Spacer(Modifier.height(8.dp))
            Tog("Não perturbe", "Sem notificações e ligações atrapalhando a partida", dnd) { dnd = it; save("dnd", it) }
            Spacer(Modifier.height(8.dp))
            Tog("Animações rápidas", "Deixa as animações do sistema mais leves enquanto joga", anim) { anim = it; save("anim", it) }
            Spacer(Modifier.height(16.dp))

            Tog("Turbo automático", "Liga sozinho quando o Free Fire abre e desliga quando você sai", auto) {
                auto = it; save("auto", it)
                if (it) startAuto() else stopAuto()
            }
            Spacer(Modifier.height(16.dp))

            if (countdown > 0) {
                Text("Confirme em ${countdown}s ou volta ao padrão", color = Red, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Btn("Manter esta resolução", true) { confirm() }
            } else {
                Btn("Ligar Turbo e abrir Free Fire", true) { turboOn() }
                Spacer(Modifier.height(10.dp))
                Btn("Testar resolução (15 segundos)", false) { test() }
            }
            Spacer(Modifier.height(10.dp))
            Btn("Desligar Turbo e restaurar tudo", false) { turboOff() }
        }

        if (msg.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(msg, color = Gray, fontSize = 13.sp)
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun Tog(title: String, desc: String, on: Boolean, change: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Panel).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = Gray, fontSize = 12.sp)
        }
        Spacer(Modifier.width(10.dp))
        Switch(checked = on, onCheckedChange = change, colors = SwitchDefaults.colors(checkedTrackColor = Red))
    }
}

@Composable
fun Btn(text: String, filled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(if (filled) Red else Panel)
            .clickable { onClick() }.padding(vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
}
