package com.ffboost.app

import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import rikka.shizuku.Shizuku

private val Red = Color(0xFFE10600)
private val Bg = Color(0xFF0A0A0A)
private val Card = Color(0xFF181818)
private val Gray = Color(0xFF9A9A9A)

data class Disp(val w: Int, val h: Int, val dpi: Int) {
    fun at(p: Int) = Triple(w * p / 100 / 2 * 2, h * p / 100 / 2 * 2, dpi * p / 100)
}

object Sh {
    fun exec(cmd: String): String {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
        val out = p.inputStream.bufferedReader().readText()
        p.waitFor()
        return out
    }

    fun disp(): Disp? {
        val s = Regex("Physical size: (\\d+)x(\\d+)").find(exec("wm size")) ?: return null
        val d = Regex("Physical density: (\\d+)").find(exec("wm density")) ?: return null
        return Disp(s.groupValues[1].toInt(), s.groupValues[2].toInt(), d.groupValues[1].toInt())
    }

    fun apply(d: Disp, p: Int) {
        if (p >= 100) { reset(); return }
        val (w, h, x) = d.at(p)
        exec("wm size ${w}x$h; wm density $x")
    }

    fun reset() { exec("wm size reset; wm density reset") }
}

fun openGame(ctx: Context): Boolean {
    val pm = ctx.packageManager
    val i = pm.getLaunchIntentForPackage("com.dts.freefireth")
        ?: pm.getLaunchIntentForPackage("com.dts.freefiremax") ?: return false
    ctx.startActivity(i)
    return true
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf(0) }
    var disp by remember { mutableStateOf<Disp?>(null) }
    var pct by remember { mutableStateOf(75) }
    var countdown by remember { mutableStateOf(0) }
    var job by remember { mutableStateOf<Job?>(null) }
    var msg by remember { mutableStateOf("") }

    fun refresh() {
        status = when {
            !Shizuku.pingBinder() -> 0
            Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> 1
            else -> 2
        }
        if (status == 2) scope.launch {
            disp = withContext(Dispatchers.IO) { runCatching { Sh.disp() }.getOrNull() }
        }
    }

    LaunchedEffect(Unit) { refresh() }
    DisposableEffect(Unit) {
        val l = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }
        Shizuku.addRequestPermissionResultListener(l)
        onDispose { Shizuku.removeRequestPermissionResultListener(l) }
    }

    fun doReset() {
        job?.cancel(); countdown = 0
        scope.launch(Dispatchers.IO) { runCatching { Sh.reset() } }
        msg = "Resolução padrão restaurada"
    }

    fun test() {
        val d = disp ?: return
        job?.cancel()
        job = scope.launch {
            withContext(Dispatchers.IO) { runCatching { Sh.apply(d, pct) } }
            countdown = 15
            while (countdown > 0) { delay(1000); countdown-- }
            withContext(Dispatchers.IO) { runCatching { Sh.reset() } }
            msg = "Sem confirmação: voltou ao padrão"
        }
    }

    fun confirm() {
        job?.cancel(); countdown = 0
        msg = "Resolução mantida"
    }

    fun playNow() {
        val d = disp ?: return
        job?.cancel(); countdown = 0
        scope.launch {
            withContext(Dispatchers.IO) { runCatching { Sh.apply(d, pct) } }
            msg = if (openGame(ctx)) "Abrindo Free Fire" else "Free Fire não encontrado"
        }
    }

    Column(
        Modifier.fillMaxSize().background(Bg)
            .verticalScroll(rememberScrollState()).padding(20.dp)
    ) {
        Text("FF BOOST", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Black)
        Text("Resolução da tela para Free Fire", color = Gray, fontSize = 14.sp)
        Spacer(Modifier.height(20.dp))

        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Card).padding(16.dp)) {
            Text(
                when (status) {
                    0 -> "Shizuku desligado. Abra o app Shizuku e inicie o serviço."
                    1 -> "Falta permissão do Shizuku para este app."
                    else -> disp?.let { "Tela original: ${it.w}x${it.h}  (${it.dpi} dpi)" } ?: "Lendo a tela..."
                },
                color = Color.White, fontSize = 15.sp
            )
        }
        Spacer(Modifier.height(16.dp))

        if (status == 0) Btn("Verificar de novo", true) { refresh() }
        if (status == 1) Btn("Dar permissão", true) { Shizuku.requestPermission(1) }

        val d = disp
        if (status == 2 && d != null) {
            Text("Escolha a resolução", color = Gray, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(100, 90, 75, 60).forEach { p ->
                    Box(
                        Modifier.weight(1f).clip(RoundedCornerShape(12.dp))
                            .background(if (p == pct) Red else Card)
                            .clickable { pct = p }.padding(vertical = 16.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("$p%", color = Color.White, fontWeight = FontWeight.Bold) }
                }
            }
            val (w, h, x) = d.at(pct)
            Spacer(Modifier.height(10.dp))
            Text("Resultado: ${w}x$h  ($x dpi)", color = Gray, fontSize = 13.sp)
            Spacer(Modifier.height(20.dp))

            if (countdown > 0) {
                Text("Confirme em ${countdown}s ou volta ao padrão", color = Red, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Btn("Manter esta resolução", true) { confirm() }
            } else {
                Btn("Testar (15 segundos)", false) { test() }
                Spacer(Modifier.height(10.dp))
                Btn("Aplicar e abrir Free Fire", true) { playNow() }
            }
            Spacer(Modifier.height(10.dp))
            Btn("Restaurar padrão", false) { doReset() }
        }

        if (msg.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            Text(msg, color = Gray, fontSize = 13.sp)
        }
    }
}

@Composable
fun Btn(text: String, filled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(if (filled) Red else Card)
            .clickable { onClick() }.padding(vertical = 16.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
}
